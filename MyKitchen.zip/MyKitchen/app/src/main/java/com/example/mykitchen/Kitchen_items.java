package com.example.mykitchen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Kitchen_items extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kitchen_items);
    }
}